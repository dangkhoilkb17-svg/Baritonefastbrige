package vn.fastbridge;

import java.util.Comparator;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2346;
import net.minecraft.class_2530;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public final class BridgeInventoryManager {
    private final BridgeConfig config;
    public BridgeInventoryManager(BridgeConfig config) { this.config = config; }

    public int select(class_310 client, class_2338 placementPos) {
        if (client.field_1724 == null || client.field_1687 == null) return -1;
        return java.util.stream.IntStream.range(0, 9)
            .filter(slot -> acceptable(client.field_1724.method_31548().method_5438(slot), client, placementPos))
            .boxed().min(Comparator.comparingInt(slot -> preference(client.field_1724.method_31548().method_5438(slot))))
            .map(slot -> { client.field_1724.method_31548().field_7545 = slot; return slot; }).orElse(-1);
    }

    private int preference(class_1799 stack) {
        class_2960 id = class_7923.field_41178.method_10221(stack.method_7909());
        int i = config.preferredBlocks.indexOf(id.toString());
        return i < 0 ? 1000 : i;
    }

    private boolean acceptable(class_1799 stack, class_310 client, class_2338 pos) {
        if (stack.method_7960() || !(stack.method_7909() instanceof class_1747 item)) return false;
        class_2248 block = item.method_7711();
        if (block instanceof class_2346 || block instanceof class_2237 || block instanceof class_2530) return false;
        class_2680 state = block.method_9564();
        return state.method_26234(client.field_1687, pos) && state.method_26227().method_15769() && state.method_26184(client.field_1687, pos);
    }
}

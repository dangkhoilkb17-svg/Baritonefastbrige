package vn.fastbridge;

import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1747;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_3965;

public final class BridgePlacementController {
    private final BridgeConfig config;
    public BridgePlacementController(BridgeConfig config) { this.config = config; }

    public boolean isPlaced(class_310 c, class_2338 pos) {
        return c.field_1687 != null && !c.field_1687.method_8320(pos).method_45474();
    }

    public Optional<PlacementCandidate> candidate(class_310 c, class_2338 target) {
        if (c.field_1724 == null || c.field_1687 == null || !c.field_1687.method_8320(target).method_45474()) return Optional.empty();
        for (class_2350 side : class_2350.values()) {
            class_2338 support = target.method_10093(side);
            if (c.field_1687.method_8320(support).method_45474()) continue;
            class_2350 clickedFace = side.method_10153();
            class_243 hitPos = class_243.method_24953(support).method_1019(class_243.method_24954(clickedFace.method_10163()).method_1021(0.5));
            if (c.field_1724.method_33571().method_1025(hitPos) > config.reach * config.reach) continue;
            return Optional.of(new PlacementCandidate(target, new class_3965(hitPos, clickedFace, support, false)));
        }
        return Optional.empty();
    }

    public boolean interact(class_310 c, PlacementCandidate candidate) {
        if (c.field_1724 == null || c.field_1761 == null) return false;
        if (!(c.field_1724.method_6047().method_7909() instanceof class_1747)) return false;
        class_1269 result = c.field_1761.method_2896(c.field_1724, class_1268.field_5808, candidate.hit());
        if (result.method_23665()) c.field_1724.method_6104(class_1268.field_5808);
        return result.method_23665();
    }
}

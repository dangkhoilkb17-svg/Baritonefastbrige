package vn.fastbridge;

import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;

public record BridgePlan(class_2338 origin, class_2350 forward, class_2350 lateral, int length, int width,
                         List<class_2338> orderedTargets) {
    public class_2338 target(int row, int lane) {
        int offset = lane - (width - 1) / 2;
        return origin.method_10079(forward, row + 1).method_10079(lateral, offset);
    }
}

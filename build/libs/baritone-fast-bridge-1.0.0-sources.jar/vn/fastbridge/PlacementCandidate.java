package vn.fastbridge;

import net.minecraft.class_2338;
import net.minecraft.class_3965;

public record PlacementCandidate(class_2338 target, class_3965 hit) {}

package vn.fastbridge;

import net.minecraft.class_2338;
import net.minecraft.class_310;

public final class BridgeSafetyManager {
    private final BridgeConfig config;
    public BridgeSafetyManager(BridgeConfig config) { this.config = config; }

    public boolean mayMove(class_310 client, BridgePlan plan) {
        if (client.field_1724 == null || client.field_1687 == null || !client.field_1724.method_5805()) return false;
        class_2338 feetFloor = client.field_1724.method_24515().method_10074();
        if (!client.field_1687.method_8320(feetFloor).method_45474()) return true;
        int row = rowAt(client, plan);
        for (int ahead = 0; ahead < config.safetyMargin; ahead++) {
            int r = row + ahead;
            if (r < 0 || r >= plan.length()) continue;
            class_2338 center = plan.target(r, (plan.width() - 1) / 2);
            if (client.field_1687.method_8320(center).method_45474()) return false;
        }
        return true;
    }

    public int rowAt(class_310 c, BridgePlan p) {
        double dx = c.field_1724.method_23317() - (p.origin().method_10263() + .5);
        double dz = c.field_1724.method_23321() - (p.origin().method_10260() + .5);
        return (int)Math.floor(dx * p.forward().method_10148() + dz * p.forward().method_10165());
    }
}

package vn.fastbridge;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_746;

public final class BridgePlanner {
    public BridgePlan create(class_746 player, int length, int width) {
        class_2350 forward = player.method_5735();
        class_2350 lateral = forward.method_10170();
        class_2338 origin = player.method_24515().method_10074();
        List<class_2338> targets = new ArrayList<>(length * width);
        int center = (width - 1) / 2;
        for (int row = 0; row < length; row++) {
            targets.add(origin.method_10079(forward, row + 1));
            for (int d = 1; d <= width; d++) {
                int left = center - d;
                int right = center + d;
                if (left >= 0) targets.add(origin.method_10079(forward, row + 1).method_10079(lateral, left - center));
                if (right < width) targets.add(origin.method_10079(forward, row + 1).method_10079(lateral, right - center));
            }
        }
        return new BridgePlan(origin, forward, lateral, length, width, List.copyOf(targets));
    }
}

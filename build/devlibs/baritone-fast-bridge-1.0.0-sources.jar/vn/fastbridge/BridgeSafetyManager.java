package vn.fastbridge;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;

public final class BridgeSafetyManager {
    private final BridgeConfig config;
    public BridgeSafetyManager(BridgeConfig config) { this.config = config; }

    public boolean mayMove(MinecraftClient client, BridgePlan plan) {
        if (client.player == null || client.world == null || !client.player.isAlive()) return false;
        BlockPos feetFloor = client.player.getBlockPos().down();
        if (!client.world.getBlockState(feetFloor).isReplaceable()) return true;
        int row = rowAt(client, plan);
        for (int ahead = 0; ahead < config.safetyMargin; ahead++) {
            int r = row + ahead;
            if (r < 0 || r >= plan.length()) continue;
            BlockPos center = plan.target(r, (plan.width() - 1) / 2);
            if (client.world.getBlockState(center).isReplaceable()) return false;
        }
        return true;
    }

    public int rowAt(MinecraftClient c, BridgePlan p) {
        double dx = c.player.getX() - (p.origin().getX() + .5);
        double dz = c.player.getZ() - (p.origin().getZ() + .5);
        return (int)Math.floor(dx * p.forward().getOffsetX() + dz * p.forward().getOffsetZ());
    }
}

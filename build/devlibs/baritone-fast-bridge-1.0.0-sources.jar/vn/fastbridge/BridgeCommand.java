package vn.fastbridge;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class BridgeCommand {
    private final BridgeController controller;
    private final BridgeConfig config;
    public BridgeCommand(BridgeController controller, BridgeConfig config) { this.controller = controller; this.config = config; }

    public void register() {
        ClientSendMessageEvents.ALLOW_CHAT.register(message -> {
            if (!message.trim().toLowerCase().startsWith("#bridge")) return true;
            execute(message.trim().substring(1));
            return false;
        });
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
            literal("bridge")
                .executes(ctx -> { controller.start(config.defaultLength, config.defaultWidth); return 1; })
                .then(literal("stop").executes(ctx -> { controller.stop(); return 1; }))
                .then(argument("length", IntegerArgumentType.integer(1, config.maxLength))
                    .executes(ctx -> { controller.start(IntegerArgumentType.getInteger(ctx, "length"), config.defaultWidth); return 1; })
                    .then(argument("width", IntegerArgumentType.integer(1, config.maxWidth))
                        .executes(ctx -> { controller.start(IntegerArgumentType.getInteger(ctx, "length"), IntegerArgumentType.getInteger(ctx, "width")); return 1; })))
        ));
    }

    private void execute(String input) {
        String[] a = input.split("\s+");
        try {
            if (a.length == 1) controller.start(config.defaultLength, config.defaultWidth);
            else if (a.length == 2 && a[1].equalsIgnoreCase("stop")) controller.stop();
            else if (a.length == 2) controller.start(Integer.parseInt(a[1]), config.defaultWidth);
            else if (a.length == 3) controller.start(Integer.parseInt(a[1]), Integer.parseInt(a[2]));
            else controller.start(-1, -1);
        } catch (NumberFormatException e) { controller.start(-1, -1); }
    }
}

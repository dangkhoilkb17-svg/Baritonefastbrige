package vn.fastbridge;

import baritone.api.IBaritone;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import java.util.HashMap;
import java.util.Map;

public final class BridgeController {
    private final MinecraftClient client = MinecraftClient.getInstance();
    private final BridgeConfig config;
    private final BridgePlanner planner = new BridgePlanner();
    private final BridgeInventoryManager inventory;
    private final BridgePlacementController placement;
    private final BridgeSafetyManager safety;
    private final BridgeMovementController movement;
    private final BridgeProcess process;
    private BridgeState state = BridgeState.IDLE;
    private BridgePlan plan;
    private final Map<BlockPos,Integer> attempts = new HashMap<>();
    private BlockPos pending;
    private int pendingTick;
    private int tick;
    private int placed;

    public BridgeController(IBaritone baritone, BridgeConfig config) {
        this.config = config; inventory = new BridgeInventoryManager(config);
        placement = new BridgePlacementController(config); safety = new BridgeSafetyManager(config);
        movement = new BridgeMovementController(baritone, config);
        process = new BridgeProcess(baritone.getPathingControlManager());
    }

    public boolean active() { return state != BridgeState.IDLE; }
    public void start(int length, int width) {
        if (client.player == null || client.world == null) { message("Bridge unavailable: not in a world."); return; }
        if (length < 1 || length > config.maxLength || width < 1 || width > config.maxWidth) {
            message("Usage: #bridge [length 1-" + config.maxLength + "] [width 1-" + config.maxWidth + "] | stop"); return;
        }
        stopInternal(null, false);
        plan = planner.create(client.player, length, width); placed = 0; tick = 0; attempts.clear(); pending = null;
        state = BridgeState.PREPARING; process.setActive(true);
        message("Fast Bridge started: length=" + length + ", width=" + width + ".");
    }

    public void stop() { stopInternal(BridgeStopReason.CANCELLED, true); }
    public void disconnect() { if (active()) stopInternal(BridgeStopReason.DISCONNECTED, false); }

    public void tick() {
        if (!active()) return;
        tick++;
        if (client.player == null || client.world == null) { fail(BridgeState.DISCONNECTED, BridgeStopReason.DISCONNECTED); return; }
        if (!client.player.isAlive()) { fail(BridgeState.PLAYER_DEAD, BridgeStopReason.PLAYER_DEAD); return; }
        try {
            state = BridgeState.VERIFYING;
            if (pending != null) {
                if (placement.isPlaced(client, pending)) { placed++; attempts.remove(pending); pending = null; }
                else if (tick - pendingTick < config.verifyDelayTicks) { movement.apply(safety.mayMove(client, plan), false); return; }
                else pending = null;
            }
            if (allPlaced()) { state = BridgeState.FINISHED; stopInternal(BridgeStopReason.COMPLETED, true); return; }
            state = BridgeState.SELECTING_BLOCK;
            BlockPos target = nextReachableTarget();
            if (target != null && inventory.select(client, target) < 0) { fail(BridgeState.NO_BLOCKS, BridgeStopReason.NO_BLOCKS); return; }

            boolean safe = safety.mayMove(client, plan);
            if (target != null) {
                state = BridgeState.PLACEMENT;
                var candidate = placement.candidate(client, target);
                if (candidate.isPresent()) {
                    int n = attempts.merge(target, 1, Integer::sum);
                    if (n > config.placementRetryLimit) { fail(BridgeState.NO_VALID_PLACEMENT, BridgeStopReason.NO_VALID_PLACEMENT); return; }
                    if (placement.interact(client, candidate.get())) { pending = target; pendingTick = tick; }
                }
            }
            state = BridgeState.MOVING;
            movement.apply(safe, !safe);
            if (!safe && target == null) fail(BridgeState.PLAYER_UNSAFE, BridgeStopReason.PLAYER_UNSAFE);
        } catch (RuntimeException e) {
            BaritoneFastBridge.LOGGER.error("Bridge tick failed", e);
            fail(BridgeState.PLAYER_UNSAFE, BridgeStopReason.INTERNAL_ERROR);
        }
    }

    private BlockPos nextReachableTarget() {
        state = BridgeState.PLANNING;
        BlockPos nearest = null; double best = Double.MAX_VALUE;
        for (BlockPos p : plan.orderedTargets()) {
            if (placement.isPlaced(client, p)) continue;
            var c = placement.candidate(client, p);
            if (c.isEmpty()) continue;
            double d = client.player.getEyePos().squaredDistanceTo(c.get().hit().getPos());
            if (d < best) { best = d; nearest = p; }
        }
        return nearest;
    }

    private boolean allPlaced() {
        for (BlockPos p : plan.orderedTargets()) if (!placement.isPlaced(client, p)) return false;
        return true;
    }
    private void fail(BridgeState error, BridgeStopReason reason) { state = error; stopInternal(reason, true); }
    private void stopInternal(BridgeStopReason reason, boolean report) {
        movement.release(); process.setActive(false);
        if (report && reason != null) {
            int total = plan == null ? 0 : plan.length() * plan.width();
            message("Bridge stopped. Placed: " + placed + "/" + total + ". Reason: " + reason.message() + ".");
        }
        state = BridgeState.IDLE; pending = null; attempts.clear(); plan = null;
    }
    private void message(String s) { if (client.player != null) client.player.sendMessage(Text.literal(s), false); }
}

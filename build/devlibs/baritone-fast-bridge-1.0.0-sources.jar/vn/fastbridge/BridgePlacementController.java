package vn.fastbridge;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import java.util.Optional;

public final class BridgePlacementController {
    private final BridgeConfig config;
    public BridgePlacementController(BridgeConfig config) { this.config = config; }

    public boolean isPlaced(MinecraftClient c, BlockPos pos) {
        return c.world != null && !c.world.getBlockState(pos).isReplaceable();
    }

    public Optional<PlacementCandidate> candidate(MinecraftClient c, BlockPos target) {
        if (c.player == null || c.world == null || !c.world.getBlockState(target).isReplaceable()) return Optional.empty();
        for (Direction side : Direction.values()) {
            BlockPos support = target.offset(side);
            if (c.world.getBlockState(support).isReplaceable()) continue;
            Direction clickedFace = side.getOpposite();
            Vec3d hitPos = Vec3d.ofCenter(support).add(Vec3d.of(clickedFace.getVector()).multiply(0.5));
            if (c.player.getEyePos().squaredDistanceTo(hitPos) > config.reach * config.reach) continue;
            return Optional.of(new PlacementCandidate(target, new BlockHitResult(hitPos, clickedFace, support, false)));
        }
        return Optional.empty();
    }

    public boolean interact(MinecraftClient c, PlacementCandidate candidate) {
        if (c.player == null || c.interactionManager == null) return false;
        if (!(c.player.getMainHandStack().getItem() instanceof BlockItem)) return false;
        ActionResult result = c.interactionManager.interactBlock(c.player, Hand.MAIN_HAND, candidate.hit());
        if (result.isAccepted()) c.player.swingHand(Hand.MAIN_HAND);
        return result.isAccepted();
    }
}

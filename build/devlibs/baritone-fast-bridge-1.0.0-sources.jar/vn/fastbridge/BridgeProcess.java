package vn.fastbridge;

import baritone.api.pathing.goals.Goal;
import baritone.api.pathing.calc.IPathingControlManager;
import baritone.api.process.IBaritoneProcess;
import baritone.api.process.PathingCommand;
import baritone.api.process.PathingCommandType;

public final class BridgeProcess implements IBaritoneProcess {
    private volatile boolean active;
    public BridgeProcess(IPathingControlManager manager) { manager.registerProcess(this); }
    public void setActive(boolean active) { this.active = active; }
    @Override public boolean isActive() { return active; }
    @Override public PathingCommand onTick(boolean calcFailed, boolean isSafeToCancel) {
        return new PathingCommand((Goal)null, PathingCommandType.REQUEST_PAUSE);
    }
    @Override public boolean isTemporary() { return false; }
    @Override public void onLostControl() { }
    @Override public double priority() { return 1.0; }
    @Override public String displayName0() { return "Fast Bridge"; }
}

package vn.fastbridge;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.ArrayList;
import java.util.List;

public final class BridgePlanner {
    public BridgePlan create(ClientPlayerEntity player, int length, int width) {
        Direction forward = player.getHorizontalFacing();
        Direction lateral = forward.rotateYClockwise();
        BlockPos origin = player.getBlockPos().down();
        List<BlockPos> targets = new ArrayList<>(length * width);
        int center = (width - 1) / 2;
        for (int row = 0; row < length; row++) {
            targets.add(origin.offset(forward, row + 1));
            for (int d = 1; d <= width; d++) {
                int left = center - d;
                int right = center + d;
                if (left >= 0) targets.add(origin.offset(forward, row + 1).offset(lateral, left - center));
                if (right < width) targets.add(origin.offset(forward, row + 1).offset(lateral, right - center));
            }
        }
        return new BridgePlan(origin, forward, lateral, length, width, List.copyOf(targets));
    }
}
